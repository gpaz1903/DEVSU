
require('cypress-plugin-tab')
class PurchasePage {
    fillForm() {
      cy.get('#name').type("GREY PAZ").tab()
      .type("Colombia").tab()
      .type("Santa Marta").tab()
      .type("45632221").tab()
      .type("junio").tab()
      .type("2025")
    }
  
    completePurchase() {
      cy.contains('Purchase').click();
    }
  
    elementExists(selector) {
      return cy.get('body').then(body => {
        return body.find(selector).length > 0;
      });
    }
    
    validatePurchase() {
      cy.contains('Thank you for your purchase!').then((element) => {
        if (element.is(':visible')) {
          cy.screenshot();
        } else {
          throw new Error('Thank you message not visible.');
        }
      });
    }
  }
  
  export default PurchasePage;
  //
  